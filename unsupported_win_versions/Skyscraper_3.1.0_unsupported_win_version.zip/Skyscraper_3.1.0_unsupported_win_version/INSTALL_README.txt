First things first: Skyscraper runs under Windows but was not designed for it.
So you might run into some issues I haven't thought about. So let me be very
clear about this: I DO NOT SUPPORT THE WINDOWS VERSION! YOU ARE ON YOUR OWN!

IMPORTANT! In order for Skyscraper to work under Windows, you need to copy all
folders from within the "deploy" folder to the C:\Users\<YOURUSER> folder.
If you don't IT WON'T RUN!!!

You need to copy them so you end up with the following folders:
C:\Users\<YOURUSER>\.skyscraper
C:\Users\<YOURUSER>\RetroPie